import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import Login from "./Components/Login";
import Signup from "./Components/Signup";
import Forum from "./Components/Forum";
import Home from "./Components/Home";
import {useState} from 'react'
import {Route, Routes, Link, useNavigate, Navigate} from 'react-router-dom'
import axios from 'axios'

import {Form,Button,Container,Navbar,Nav} from 'react-bootstrap'

const api = axios.create({
  baseURL: 'http://localhost'
})

function App() {

  const[user,setUser] = useState({name:"", email:""});
  const[error,setError] = useState("");

  const Signin = details => {
    console.log(details)

    setUser({
      name: details.name,
      email: details.email
    });

  }
  const test = () =>{
    console.log(user)
  }

  const Logout =  () => {
    console.log(user)
    setUser({name:"", email:""});
  }

  return (
    <div className="App">
      <Navbar bg="dark" variant="dark">
        <Container>
          <Nav className="me-auto">
            <Link to='/'><Nav.Link href='/'>Home</Nav.Link></Link>
            <Link to='/Login'><Nav.Link href="Login">Login</Nav.Link></Link>
            <Link to='/Signup'><Nav.Link href="Signup">Sign Up</Nav.Link></Link>
            <Link to='/Forum'><Nav.Link href="Forum">Forum</Nav.Link></Link>
          </Nav>
        </Container>
      </Navbar>
      <Routes>
        <Route exact path='/' element={<Home user = {user}/>} />
        <Route path='/Login' element={<Login Signin = {Signin} error={error}/>} />
        <Route path='/Signup' element={<Signup/>} />
        <Route path='/Forum' element={<Forum/>} />
      </Routes>
    </div>
  );
}

export default App;
