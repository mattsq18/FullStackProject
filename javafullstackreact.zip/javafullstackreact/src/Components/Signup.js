import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import {Form,Button,Container,Navbar} from 'react-bootstrap'
import {Link} from 'react-router-dom'

const Signup = () => {
  return (
    <div className="App">
      <header className="App-header" >
        <Form>
          <Form.Group className="mb-3" controlId='formBasicEmail'>
            <Form.Label>Username</Form.Label>
            <Form.Control type="email" placeholder="Username" />
          </Form.Group>

          <Form.Group className="mb-3" controlId='formBasicPassword'>
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" placeholder="Password" />
          </Form.Group>

          <Form.Group className="mb-3" controlId='formBasicPassword'>
            <Form.Label>Re-Enter Password</Form.Label>
            <Form.Control type="password" placeholder="Password" />
          </Form.Group>

          <Button>Sign Up</Button>

        </Form>
        <h4 class="fs-6">Have an account? <Link to="/Login">log in</Link> </h4>
      </header>
    </div>
  )
}

export default Signup