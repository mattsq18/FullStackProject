import React from 'react'
import ForumPost from "./ForumPost";

const Forum = () => {
  return (
    <div>
        <ForumPost username="Jone" posttext="This is a test"></ForumPost>
    </div>
  )
}

export default Forum