package com.genspark.ProjectFullStack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectFullStackApplicationTests {

	@Test
	void contextLoads() {
	}

}
